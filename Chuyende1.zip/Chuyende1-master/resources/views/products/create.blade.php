@extends('layout.master')

@section('content')

<h3>Thêm sản phẩm</h3>

<form method="POST" action="{{ route('products.store') }}" enctype="multipart/form-data">
@csrf

<div class="mb-3">
    <label>Tên</label>
    <input name="name" class="form-control">
</div>

<div class="mb-3">
    <label>Giá</label>
    <input name="price" class="form-control">
</div>

<div class="mb-3">
    <label>Số lượng</label>
    <input name="quantity" class="form-control">
</div>

<div class="mb-3">
    <label>Danh mục</label>
    <select name="category_id" class="form-select">
        @foreach($categories as $c)
            <option value="{{ $c->id }}">{{ $c->name }}</option>
        @endforeach
    </select>
</div>

<div class="mb-3">
    <label>Ảnh</label>
    <input type="file" name="image" class="form-control">
</div>

<button class="btn btn-success">Lưu</button>
<a href="/products" class="btn btn-secondary">Quay lại</a>

</form>

@endsection