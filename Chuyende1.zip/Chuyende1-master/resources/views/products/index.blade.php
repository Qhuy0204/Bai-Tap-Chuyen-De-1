@extends('layout.master')

@section('content')

<div class="d-flex justify-content-between mb-3">
    <h3>Danh sách sản phẩm</h3>
    <a href="{{ route('products.create') }}" class="btn btn-primary">+ Thêm</a>
</div>

<!-- Search + Sort -->
<form class="row mb-3">
    <div class="col-md-4">
        <input type="text" name="search" class="form-control" placeholder="Tìm sản phẩm...">
    </div>

    <div class="col-md-3">
        <select name="sort" class="form-select">
            <option value="">Sắp xếp giá</option>
            <option value="asc">Tăng dần</option>
            <option value="desc">Giảm dần</option>
        </select>
    </div>

    <div class="col-md-2">
        <button class="btn btn-success">Lọc</button>
    </div>
</form>

<div class="row mb-3">
    <div class="col-md-6">
        <div class="alert alert-primary">
            Tổng sản phẩm: <b>{{ $totalProducts }}</b>
        </div>
    </div>

    <div class="col-md-6">
        <div class="alert alert-success">
            Tổng danh mục: <b>{{ $totalCategories }}</b>
        </div>
    </div>
</div>

<div class="card mb-3">
    <div class="card-header">5 sản phẩm mới nhất</div>
    <ul class="list-group list-group-flush">
        @foreach($latestProducts as $item)
            <li class="list-group-item">
                {{ $item->name }} - 
                <span class="text-danger">
                    {{ number_format($item->price, 0, ',', '.') }} ₫
                </span>
            </li>
        @endforeach
    </ul>
</div>
<table class="table table-bordered table-hover text-center">
    <thead class="table-dark">
        <tr>
            <th>Tên</th>
            <th>Giá</th>
            <th>Danh mục</th>
            <th>Ảnh</th>
            <th>Hành động</th>
        </tr>
    </thead>

    <tbody>
    @foreach($products as $p)
        <tr>
            <td>{{ $p->name }}</td>
            <td>{{ number_format($p->price, 0, ',', '.') }} VND</td>
            <td>{{ $p->category->name }}</td>
            <td>
                <img src="{{ asset('storage/'.$p->image) }}" width="70" class="rounded">
            </td>
            <td>
                <a href="{{ route('products.edit',$p->id) }}" class="btn btn-warning btn-sm">Sửa</a>

                <form method="POST" action="{{ route('products.destroy',$p->id) }}" style="display:inline">
                    @csrf
                    @method('DELETE')
                    <button onclick="return confirm('Xóa sản phẩm?')" class="btn btn-danger btn-sm">
                        Xóa
                    </button>
                </form>
            </td>
        </tr>
    @endforeach
    </tbody>
</table>

<!-- Pagination -->
<div class="d-flex justify-content-center">
    {{ $products->links() }}
</div>

@endsection